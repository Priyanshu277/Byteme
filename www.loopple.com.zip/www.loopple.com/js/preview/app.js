let googleFontImportURL = document.querySelector('#google-font-url')?.href;
let fontDisplay;
let fontBody;
let framework = document.querySelector('body').getAttribute("data-framework");
const root = document.querySelector(':root');


addFontFamilyToHeadStyle();

// Function to add font family to head
function addFontFamilyToHeadStyle(){

  let fontFamilies = new URL(googleFontImportURL).searchParams.get('family');
  const fontsStyle = document.querySelector('style') ? document.querySelector('style').sheet : '';
  let rules = fontsStyle.rules || fontsStyle.cssRules;

  if(fontFamilies){
    // Split font families based on the pipe character (|)
    let fontArray = fontFamilies.split('|');

    // Extracting individual font families
    fontDisplay = fontArray[0] ? extractFontFamily(fontArray[0]) : '';
    fontBody = fontArray[1] ? extractFontFamily(fontArray[1]) : '';

    // Conditions for Bootstrap fonts
    let fontSansSerif = framework === 'bootstrap5' ? '--bs-font-sans-serif' : '--font-family-sans-serif';
    let fontMonospace = framework === 'bootstrap5' ? '--bs-font-monospace' : '--font-family-monospace';

    document.querySelector('html').style.setProperty(fontSansSerif, '');
    document.querySelector('html').style.setProperty(fontMonospace, '');

    root.style.setProperty(fontSansSerif, fontDisplay);
    root.style.setProperty(fontMonospace, fontBody);

    // End conditions for Bootstrap fonts
  }

  // Change font in the root style
  for (let i = 0; i < rules.length; i++) {
    if (rules[i].selectorText === `.font-display`) {
      rules[i].style.fontFamily = fontDisplay.replaceAll("+", ' ');
    }
    if (rules[i].selectorText === `.font-body`) {
      rules[i].style.fontFamily = fontBody.replaceAll("+", ' ');
    }
  }
}

// Function to extract font family without weight
function extractFontFamily(fontString) {
    var match = fontString.match(/([^:]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}
